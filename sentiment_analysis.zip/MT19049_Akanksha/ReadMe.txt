In folder MT19049_Akanksha_Code there are 2 file in which i
 had use two different type of methods in feature extraction
so conscider it.

MT19049_Akanksha_Code1:Done by CountVectorizer
MT19049_Akanksha_Code2:Done by TfidfVectorizer

*Tweets.csv is here my dataset.